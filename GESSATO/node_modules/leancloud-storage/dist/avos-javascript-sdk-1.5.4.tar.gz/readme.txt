解压后的文件包括：

av-es6.js       未经压缩的 JavaScript SDK（ECMAScript 6 版本）
av.js           编译后的 JavaScript SDK（ECMAScript 5 版本）
av-min.js      经编译压缩后生成的 JavaScript SDK （ECMAScript 5 版本）

快速入门： https://leancloud.cn/start.html
开发指南： https://leancloud.cn/docs/js_guide.html
技术支持： https://leanticket.cn/t/leancloud/
技术社区： https://forum.leancloud.cn

感谢您对 LeanCloud 的支持，有任何疑问都可以到提交工单获取帮助。
